# License

```{include} ../../LICENSE
```
