# XLSB 라이브러리 및 파생 구현 소스

pyxlsb/에는 빌드 환경에서 사용한 라이브러리 파일을, maeumnarae/services/에는
현재 앱의 파생 구현과 읽기 인터페이스를 수록합니다. 원본과의 차이는 CHANGES.md에 있습니다.
pyxlsb와 memory_xlsb.py는 LGPL-3.0-or-later, xlsb_reader.py는 MIT입니다.
LICENSE는 MIT 부분에만 적용됩니다. GPL/LGPL 전문과 저작권 고지는 resources/licenses/에 있습니다.
라이브러리 수정 및 수정 사항 디버깅을 위한 역공학을 제한하지 않습니다.

upstream-build-reference/는 공식 원본의 빌드 메타데이터 참고용입니다.
수정본의 빌드 설정을 대신하지 않으며 이 묶음은 앱 전체 재빌드 키트가 아닙니다.
앱 소스·의존성·재빌드 절차 제공은 별도 릴리스 자료로 준비해야 합니다.
CONTENTS.json은 수록 파일의 SHA-256과 설치 모듈 버전을 기록합니다.
